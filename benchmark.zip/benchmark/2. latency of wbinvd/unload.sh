sudo rmmod disablecache
