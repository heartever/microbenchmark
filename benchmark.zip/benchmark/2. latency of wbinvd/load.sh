sudo insmod disablecache.ko
